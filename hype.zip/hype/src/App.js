import React from 'react';
import './App.css';

// REACT ROUTER
import { Router, Route, Switch } from 'react-router-dom';

// BOOTSTRAP
import 'bootstrap/dist/css/bootstrap.min.css';


// IMPORTS LAYOUTS COMPONENTS
import Navigation from './components/layouts/Navigation';
import Footer from './components/layouts/Footer';

// IMPORTS PAGES COMPONENTS
import Home from './components/pages/Home';
import Eventos from './components/pages/Eventos';
import Residentes from './components/pages/Residentes';
import Media from './components/pages/Media';
import Tienda from './components/pages/Tienda';
import Details from './components/layouts/Details';
import Cart from './components/pages/Cart';
import {NoMatch} from './components/pages/NoMatch';
import {Layout} from './components/Layout';


class App extends React.Component {
  render() {
    return (
      <React.Fragment>
        <Layout>
          <Navigation />
          <Switch>
            <Route exact path='/' component={Home} />
            <Route path='/eventos' component={Eventos} />
            <Route path='/residentes' component={Residentes} />
            <Route path='/media' component={Media} />
            <Route path='/tienda' component={Tienda} />
            <Route path='/details' component={Details} />
            <Route path='/cart' component={Cart} />
            <Route component={NoMatch} />
          </Switch>
          <Footer />
        </Layout>
      </React.Fragment>
    )
  }
}

export default App;