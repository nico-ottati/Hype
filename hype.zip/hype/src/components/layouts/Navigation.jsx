import React, { Component } from 'react';
import { Navbar, Nav } from 'react-bootstrap';
import styled from 'styled-components';

// REACT ROUTER DOM
import { Link } from "react-router-dom";

//IMPORT INFOCONSUMER
import { InfoConsumer } from "../context";

// IMPORTS FONTAWESOME
import { FontAwesomeIcon } from '@fortawesome/react-fontawesome';
import { faShoppingCart } from "@fortawesome/free-solid-svg-icons";

import Logo from '../../images/branding/Hype_Logo_Blanco.png';

const Styles = styled.div`
    nav {
        position: sticky;
        top: 0;
    }

    .navbar {
        background-color: black;
        border-bottom: 1px groove white;
        padding-left: 0;
        padding-right: 0;
    }

    .navbar .navbar-brand, .navbar-nav .nav-link {
        opacity: 1;
        transition: 0.3s;
        &:hover {
            opacity: 0.7;
        }
    }

    .navbar-toggler-icon {
        background-image: url("data:image/svg+xml;charset=utf8,%3Csvg viewBox='0 0 32 32' xmlns='http://www.w3.org/2000/svg'%3E%3Cpath stroke='rgba(255,255,255, 1)' stroke-width='2' stroke-linecap='round' stroke-miterlimit='10' d='M4 8h24M4 16h24M4 24h24'/%3E%3C/svg%3E");
        opacity: 1;
        transition: 0.3s;
        &:hover {
            opacity: 0.7;
        }
    }

`;

export default class navigation extends Component {
  render() {
    return (
      <Styles>
        <Navbar expand="lg" className="sticky-nav h-100 mb-5 py-3">
          <Navbar.Brand className="pr-2">
            <Link to="/">
            <img
              alt="Hype Logo"
              src={Logo}
              width="120"
              height="50"
              className="d-inline-block align-top"
            />
            </Link>
          </Navbar.Brand>
          <Navbar.Toggle
            aria-controls="responsive-navbar-nav"
            className="border-0 pr-0 float-right"
          />
          <Navbar.Collapse
            defaultActiveKey="/"
            className="justify-content-end float-right pr-0"
            id="responsive-navbar-nav"
          >
            <Nav>
              <Link className="nav-link pr-2 font-weight-light text-white" to="/eventos">
                  Eventos</Link>
              <Link className="nav-link pr-2 font-weight-light text-white" to="/residentes">
                  Residentes</Link>
              <Link className="nav-link pr-2 font-weight-light text-white" to="/media">
                  Media</Link>
              <Link className="nav-link pr-2 font-weight-light text-white" to="/tienda">
                  Tienda</Link>
            </Nav>
          </Navbar.Collapse>
          <Nav>
            <InfoConsumer>
              {(value)=> {
                return <Link eventKey={2} to="/cart"> 
                    <FontAwesomeIcon icon={faShoppingCart} id="icon" />({value.Cart.length})
                </Link>
              }}
            </InfoConsumer>
          </Nav>
        </Navbar>
      </Styles>
    );
  }
}
