import React, { Component } from "react";
import { InfoConsumer } from "../context";
/* import { Link } from 'react-router-dom'; */

// STYLED COMPONENTS
import styled from "styled-components";

// REACT BOOTSTRAP
import { Container, Button, Card } from "react-bootstrap";
import { Link } from "react-router-dom";

// IMPORTS FONTAWESOME
import { FontAwesomeIcon } from '@fortawesome/react-fontawesome';
import { faShoppingCart } from "@fortawesome/free-solid-svg-icons";

const Styles = styled.section`
  .card {
    color: white;
    background-color: black;
    border: groove 1px white;
    transition: 0.6s;
  }

  
  a .card-img-top {
    opacity: 1;
    transition: 0.6s;
    &: hover {
    opacity: 0.5;
    }
  }

  .btn {
    border: groove 1px white;
    color: white;
    background-color: black;
    opacity: 1;
    transition: 0.6s;
    &:hover {
      opacity: 0.7;
      }
    }
  }
`;

export default class Details extends Component {
  render() {
    return (
      <InfoConsumer>
        {(value) => {
          const { id, productoImg, productoTitle, productoPrice, /* productoStock, productoStockS, productoStockM, productoStockL, productoStockXL, productoSinStock, */ productoDescription, inCart, /* cuenta, */ } = value.detailProduct;
          return (
            <Styles>
              <Container className="col-8 col-sm-8 col-md-6 col-lg-4 mx-auto mb-5">
                <Card>
                  <Card.Img
                    variant="top"
                    src={productoImg}
                    alt={productoTitle}
                  />
                  <Card.Body>
                    <Card.Title className="text-center font-weight-light mb-3">
                      {productoTitle}
                    </Card.Title>
                    <Card.Subtitle className="text-center font-weight-light mb-3">
                      Precio: <span>$</span>
                      {productoPrice}
                    </Card.Subtitle>
                    <Card.Text className="font-weight-lighter text-justify text-center">
                      <small className="text-lighter">
                        {productoDescription}
                      </small>
                    </Card.Text>
                  </Card.Body>
                  <Card.Footer className="d-flex justify-content-around">
                    <Button>
                      <Link to="/tienda">Volver</Link>
                    </Button>
                    <Button
                      size="sm"
                      disabled={inCart}
                      onClick={() => {
                        value.addToCart(id);
                      }}
                      variant="secondary"
                    >
                      {inCart === true ? (
                        <span>Agregado</span>
                      ) : (
                        <span className="d-flex">
                          Agregar
                          <FontAwesomeIcon
                            className="mt-1 ml-1"
                            icon={faShoppingCart}
                            id="icon"
                          />
                        </span>
                      )}
                    </Button>
                  </Card.Footer>
                </Card>
              </Container>
            </Styles>
          );
        }}
      </InfoConsumer>
    );
  }
}
