import React, { useState } from 'react'

// BOOTSTRAP
/* import { Carousel } from 'react-bootstrap'; */
import {Carousel} from 'react-bootstrap';

// IMAGENES
/* import slide01 from "hype/public/img/carousel/img_1.jpg"; */
import slide01 from "../../images/carousel/img_1.jpg";
import slide02 from "../../images/carousel/img_2.jpg";
import slide03 from "../../images/carousel/img_3.jpg";
import slide04 from "../../images/carousel/img_4.jpg";
import slide05 from "../../images/carousel/img_5.jpg";
import slide06 from "../../images/carousel/img_6.jpg";


function CarouselHome () {
    const [index, setIndex] = useState(0);

    const handleSelect = (selectedIndex, e) => {
        setIndex(selectedIndex);
    };
    
    return (
        <Carousel activeIndex={index} onSelect={handleSelect} fade={true} interval={7000} pause={'hover'} className="w-75 mx-auto mb-5">
            <Carousel.Item>
                <img
                    className="d-block mw-100"
                    src={slide01}
                    alt="First slide"/>
            </Carousel.Item>
            <Carousel.Item>
                <img
                    className="d-block mw-100"
                    src={slide02}
                    alt="First slide"/>
            </Carousel.Item>
            <Carousel.Item>
                <img
                    className="d-block mw-100"
                    src={slide03}
                    alt="First slide"/>
            </Carousel.Item>
            <Carousel.Item>
                <img
                    className="d-block mw-100"
                    src={slide04}
                    alt="First slide"/>
            </Carousel.Item>
            <Carousel.Item>
                <img
                    className="d-block mw-100"
                    src={slide05}
                    alt="First slide"/>
            </Carousel.Item>
            <Carousel.Item>
                <img
                    className="d-block mw-100"
                    src={slide06}
                    alt="First slide"/>
            </Carousel.Item>
        </Carousel>
    )
}


export default CarouselHome;
