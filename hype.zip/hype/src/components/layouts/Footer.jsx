import React/* , { Component }  */ from 'react';
import styled from 'styled-components';

// FONTAWESOME
import { FontAwesomeIcon } from '@fortawesome/react-fontawesome'
import { faInbox } from '@fortawesome/free-solid-svg-icons'
import { faFacebook, faInstagram, faSoundcloud } from '@fortawesome/free-brands-svg-icons'
import {} from '@fortawesome/free-regular-svg-icons'

const Styles = styled.div`
  .main-footer .container {
    background-color: black;
    border-top: 1px groove white;
    padding-left: 0;
    padding-right: 0;
    .row {
      font-size: 12px;
      #iconos {
        font-size: 16px;
      }
    }

    .col #inbox,#icono {
      opacity: 1;
      transition: 0.3s;
      :hover {
        opacity: 0.7;
      }

    
`;

function Footer() {
    return (
        <Styles>
        <div className="main-footer mt-5" >
            <div className="container">
                <div className="row d-flex justify-content-between">
                    <div className="col d-flex justify-content-start py-3 font-weight-light text-white">
                        <a 
                        href="mailto:contact.hypeuy@gmail.com"
                        alt="inbox"
                        id="inbox">
                        <FontAwesomeIcon icon={faInbox}/> {''}
                        contact.hypeuy@gmail.com
                        </a>
                    </div>

                    <div className="col d-flex justify-content-center py-3 font-weight-light text-white" id="iconos">
                        <a href="https://www.facebook.com/hypeuyok/" 
                        alt="facebook" 
                        className="d-inline px-2"
                        id="icono">
                        <FontAwesomeIcon icon={faFacebook}/>
                        </a>

                        <a href="https://instagram.com/hype.uy?igshid=vrnwhleqr0mg" 
                        alt="instagram" 
                        className="d-inline px-2"
                        id="icono">
                        <FontAwesomeIcon icon={faInstagram}/>
                        </a>

                        <a href="https://soundcloud.com/hype-uruguay" 
                        alt="soundcloud" 
                        className="d-inline px-2"
                        id="icono">
                        <FontAwesomeIcon icon={faSoundcloud}/>
                        </a>
                    </div>

                    <div className="col d-flex justify-content-end py-3 font-weight-light text-white">
                        <p>Website by Nicolás Ottati</p>
                    </div>
                </div>
            </div>
        </div>
        </Styles>
    )
};

export default Footer;