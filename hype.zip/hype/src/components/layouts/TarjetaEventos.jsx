import React, { Component } from "react";
import styled from "styled-components";
import { InfoConsumer } from "../context";

// IMPORTS FONTAWESOME
import { FontAwesomeIcon } from "@fortawesome/react-fontawesome";
import { faFacebook } from "@fortawesome/free-brands-svg-icons";
import { faTicketAlt } from "@fortawesome/free-solid-svg-icons";

const Styles = styled.section`
  .card {
    color: white;
    background-color: black;
    border: groove 1px white;
    border-radius: 0;
    transition: 0.3s;
    p {
      font-size: 14px;
    }
  }

  .btn {
    border: groove 1px white;
    color: white;
    opacity: 1;
    transition: 0.3s;
    &:hover {
      opacity: 0.7;
      }
    }
  }
`;

class TarjetaEventos extends Component {
  render() {
    const {
      eventTitle,
      eventLineup,
      eventLocation,
      eventDate,
      eventImg,
      eventPassline,
      eventFacebook,
    } = this.props.item;

    return (
      <InfoConsumer>
        {(value) => (
          <Styles>
            <div className="card">
              <div className="row">
                <div class="col-md-3 col-lg-3 col-xl-3">
                  <img
                    src={eventImg}
                    alt={eventTitle}
                    className="card-img pl-md-4 pt-md-4 pb-lg-4"
                  />
                </div>
                <div className="card-body d-inline-block ml-1 pb-sm-2">
                  <h3 className="card-title text-uppercase">{eventTitle}</h3>
                  <p className="card-subtitle" id="lineup">
                    {eventLineup}
                  </p>
                  <p className="card-subtitle" id="venue">
                    <b>Venue: </b>
                    {eventLocation}
                  </p>
                  <p className="card-subtitle" id="fecha">
                    <b>Fecha: </b>
                    {eventDate}
                  </p>
                </div>
                <div className="card-body ml-md-1 p-md-3 pt-sm-0 my-md-auto d-flex flex-md-column justify-content-xs-start">
                  <a href={eventPassline} class="btn p-1 mr-2 mb-md-2">
                    <FontAwesomeIcon icon={faTicketAlt} id="icon" /> Passline
                  </a>
                  <a href={eventFacebook} class="btn p-1 mr-2 ">
                    <FontAwesomeIcon icon={faFacebook} id="icon" /> Evento
                  </a>
                </div>
              </div>
            </div>
          </Styles>
        )}
      </InfoConsumer>
    );
  }
}

export default TarjetaEventos;