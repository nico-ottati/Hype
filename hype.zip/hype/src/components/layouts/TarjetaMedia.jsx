import React, { Component } from "react";
import styled from "styled-components";
import { InfoConsumer } from "../context";

// REACT PLAYER
import ReactPlayer from "react-player";

// REACT BOOTSTRAP
import { Card, Row, Col, Button, Container } from 'react-bootstrap';


const Styles = styled.section`
  .card {
    color: white;
    background-color: black;
    border: groove 1px white;
    opacity: 0.8;
    transition: 0.6s;
    &: hover {
      opacity: 1;
    }
  }
  .player-wrapper {
    position: relative;
    padding-top: 56.25%;
    padding-right: 30%;
  }
  .react-player {
    position: absolute;
    top: 0;
    left: 0;
    right: -20;
  }
`;

class TarjetaMedia extends Component {
  render() {
    const { mediaUrl } = this.props.item;

    return (
      <InfoConsumer>
        {(value) => (
          <Container>
            <Styles>
                  <Card className="card mx-auto mb-3">
                    <ReactPlayer width="100%" url={mediaUrl} />
                  </Card>
            </Styles>
          </Container>
        )}
      </InfoConsumer>
    );
  }
}

export default TarjetaMedia;

