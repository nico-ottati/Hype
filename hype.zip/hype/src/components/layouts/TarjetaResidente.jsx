import React, { Component } from 'react';
import styled from "styled-components";
import { InfoConsumer } from '../context';

// IMPORTS FONTAWESOME
import { FontAwesomeIcon } from '@fortawesome/react-fontawesome'
import { faFacebook, faInstagram, faSoundcloud } from '@fortawesome/free-brands-svg-icons'

const Styles = styled.section`
  .card {
    color: white;
    background-color: black;
    border: groove 1px white;
    transition: 0.6s;
    p {
      font-size: 14px;
    }
  }

  .card-footer {
    border-top: groove 1px white;
    border-bottom: groove 1px white;
    #icon {
      opacity: 1;
      transition: 0.6s;
      &:hover {
        opacity: 0.7;
      }
    }
  }
`;



class TarjetaResidente extends Component {
    render() {
        const {
            residenteTitulo,
            residenteSubtitulo,
            residenteTexto,
            residenteImg1,
            residenteSoundcloud,
            residenteInstagram,
            residenteFacebook,
        } = this.props.item; 

        return (
          <InfoConsumer>
            {(value) => (
              <div className="col-sm-12 col-md-6 col-lg-4 mx-auto mb-5">
                <Styles>
                  <div className="card mx-auto">
                    <img
                      src={residenteImg1}
                      alt={residenteTitulo}
                      className="card-img-top"
                    />
                    <div className="card-body">
                      <h3 className="card-title text-uppercase font-weight-light">
                        {residenteTitulo}
                      </h3>
                      <h5 className="card-title font-weight-light">
                        {residenteSubtitulo}
                      </h5>
                      <p className="card-text font-weight-lighter">
                        {residenteTexto}
                      </p>
                      <div className="card-footer d-flex justify-content-center">
                        <a
                          href={residenteSoundcloud}
                          class="card-link d-inline"
                        >
                          <FontAwesomeIcon icon={faSoundcloud} id="icon" />
                        </a>
                        <a href={residenteInstagram} class="card-link d-inline">
                          <FontAwesomeIcon icon={faInstagram} id="icon" />
                        </a>
                        <a href={residenteFacebook} class="card-link d-inline">
                          <FontAwesomeIcon icon={faFacebook} id="icon" />
                        </a>
                      </div>
                    </div>
                  </div>
                </Styles>
              </div>
            )}
          </InfoConsumer>
        );
    }
}

export default TarjetaResidente;