import React from 'react';

// IMPORTS STYLED COMPONENTS
import styled from 'styled-components';

// IMPORTS BOOTSTRAP
import Container from 'react-bootstrap/Container';




const Styles = styled.div`
    body {
        min-height: 100vh;
        background-color: black; 
    }
`;


export const Layout = (props) => (
    <Styles>
        <Container>
            {props.children}
        </Container>
    </Styles>
)



