import React, { Component } from 'react';

//IMPORT INFOCONSUMER
import { InfoConsumer } from '../context';

//IMPORTS COMPONENTES LAYOUTS
import TarjetaResidente from "../layouts/TarjetaResidente";


 class Residentes extends Component {
    render() {
        return (

            <div className="container">
                <div className="row mt-5">
                    <InfoConsumer>
                        {value => {
                            return value.infoResidentes.map(item => {
                                return <TarjetaResidente key={item.id} item={item}/>
                            })
                        }}
                    </InfoConsumer>
                </div>
            </div>
        )
    }
}

export default Residentes;