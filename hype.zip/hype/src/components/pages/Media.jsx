import React, { Component } from "react";

//IMPORT INFOCONSUMER
import { InfoConsumer } from "../context";

//IMPORTS COMPONENTES LAYOUTS
import TarjetaMedia from "../layouts/TarjetaMedia";

class Media extends Component {
  render() {
    return (
      <div className="container">
        <div className="row mt-5">
          <InfoConsumer>
            {(value) => {
              return value.infoMedia.map((item) => {
                return <TarjetaMedia key={item.id} item={item} />;
              });
            }}
          </InfoConsumer>
        </div>
      </div>
    );
  }
}

export default Media;
