import React from 'react'

export const NoMatch = () => (
    <div>
        <h2>Error: 404</h2>
    </div>
)
