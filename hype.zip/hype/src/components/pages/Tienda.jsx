import React, { Component } from "react";

//IMPORT INFOCONSUMER
import { InfoConsumer } from "../context";

//IMPORTS COMPONENTES LAYOUTS
import Producto from "../layouts/Producto";

class Tienda extends Component {
  render() {
    return (
      <div className="container">
        <div className="row mt-5">
          <InfoConsumer>
            {(value) => {
              return value.products.map(product => {
                return <Producto key={product.id} product={product} />;
              })
            }}
          </InfoConsumer>
        </div>
      </div>
    )
  }
}

export default Tienda;
