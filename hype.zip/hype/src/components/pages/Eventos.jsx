import React, { Component } from "react";

//IMPORT INFOCONSUMER
import { InfoConsumer } from "../context";

//IMPORTS COMPONENTES LAYOUTS
import TarjetaEventos from "../layouts/TarjetaEventos";

class Eventos extends Component {
  render() {
    return (
        <InfoConsumer>
        {(value) => {
            return value.infoEventos.map((item) => {
            return <TarjetaEventos key={item.id} item={item} />;
            });
        }}
        </InfoConsumer>
    );
  }
}

export default Eventos;
