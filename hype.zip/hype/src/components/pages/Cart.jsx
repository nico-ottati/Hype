import React, { Component } from 'react';

// CONTEXT
import { InfoConsumer } from "../context";

// REACT BOOTSTRAP
import { Container, Button, Col, Row , Table } from "react-bootstrap";

// STYLED COMPONENTS
import styled from "styled-components";

const Styles = styled.section`
  section {
    color: white;
  }

  input {
    width: 25px;
    height: 25px;
    padding: 5px;
    border: 2px solid #ccc;
    margin: 2%;
  }

  .table-responsive {
    table {
      color: white;
      tbody {
        border-bottom: 1px groove white;
      }
    }
  }

  .btn {
    color: white;
    background-color: black;
    opacity: 1;
    transition: 0.6s;
    &:hover {
      opacity: 0.7;
      }
    }
  }
`;

export default class Cart extends Component {
  render() {
    return (
      <Styles>
        <section>
          <InfoConsumer>
            {value => {
              if (value.Cart.length > 0) {
                return (
                  <div>
                    <div>
                      <h1>Carrito de compras</h1>
                    </div>
                    <Table responsive>
                      <thead>
                        <tr>
                          <th>#</th>
                          <th>Producto</th>
                          <th>Nombre</th>
                          <th>Precio</th>
                          <th>Cantidad</th>
                          <th>Quitar</th>
                          <th>Subtotal</th>
                        </tr>
                      </thead>
                      
                        {value.Cart.map((cartData) => {
                          return (
                            <tbody>
                              <tr hover>
                                <td>1</td>
                                <td>
                                  <img
                                    style={{ width: "6rem", height: "6rem" }}
                                    src={cartData.productoImg}
                                    className="img-fluid"
                                    alt=""
                                  />
                                </td>
                                <td>{cartData.productoTitle}</td>
                                <td>{cartData.productoPrice}</td>
                                <td>
                                  <Row className="pl-3">
                                    <Button
                                      size="sm"
                                      className="qtyminus"
                                      value="-"
                                      variant="secondary"
                                      onClick={() =>
                                        value.decrement(cartData.id)
                                      }
                                    >-</Button>
                                    <Col className="col-1 p-0 ml-2">
                                      {cartData.cuenta}
                                    </Col>
                                    <Button
                                      size="sm"
                                      className="qtyplus"
                                      value="+"
                                      variant="secondary"
                                      onClick={() =>
                                        value.increment(cartData.id)
                                      }
                                    >+</Button>
                                  </Row>
                                </td>
                                <td>
                                  <Button
                                    onClick={() => {
                                      value.removeItem(cartData.id);
                                    }}
                                    size="sm"
                                    variant="secondary"
                                  >
                                    Quitar
                                  </Button>
                                </td>
                                <td>${cartData.total}</td>
                              </tr>
                            </tbody>
                          );
                        })}
                    </Table>
                    <hr></hr>
                    <Container>
                      <Row>
                        <Col>
                          <strong>Total </strong>${value.CartSubTotal}
                        </Col>
                      </Row>
                    </Container>
                  </div>
                );
              } else {
                return (
                  <div>
                    <h3>Tu carrito está vacío</h3>
                  </div>
                );
              }
            }}
          </InfoConsumer>
        </section>
      </Styles>
    );
  }
}
