import React, { Component } from 'react';

// REACT BOOTSTRAP
import Container from 'react-bootstrap/Container';
import Row from 'react-bootstrap/Row';
import Col from 'react-bootstrap/Col';

// STYLED COMPONENTS
/* import styled from "styled-components"; */

//IMPORTS LAYOUTS COMPONENTS
import CarouselHome from '../layouts/CarouselHome';

//IMPORTS PAGES COMPONENTS
import Eventos from './Eventos';
import Media from "./Media";

//IMPORTS BOOTSTRAP
import 'bootstrap/dist/css/bootstrap.min.css'

/* import {Carousel} from 'react-bootstrap' */



export default class Home extends Component {
    render() {            
        return (
          <Container>
            <Row>
              <Col>
                <CarouselHome />
              </Col>
            </Row>
            <Row>
              <Col className="col-12 col-xl-6">
                <Eventos />
              </Col>
              <Col className="col-12 col-xl-6">
                <Media />
              </Col>
            </Row>
          </Container>
        );
    }
}


